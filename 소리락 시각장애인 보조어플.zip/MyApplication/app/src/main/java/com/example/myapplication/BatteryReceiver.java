package com.example.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.widget.TextView;
//배터리 처리 부분
public class BatteryReceiver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {
        //잠금화면의 textview에 접근
        TextView statusLabel = ((LockscreenActivity)context).findViewById(R.id.statusLabel);
        TextView percentageLabel = ((LockscreenActivity)context).findViewById(R.id.percentageLabel);
        String action = intent.getAction();
        if (action != null && action.equals(Intent.ACTION_BATTERY_CHANGED)) {
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String message = "";
            //배터리 상태를 한글로 출력
            switch (status) {
                case BatteryManager.BATTERY_STATUS_FULL:
                    message = "충전 완료";
                    break;
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    message = "충전 중";
                    break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    message = "";
                    break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    message = "";
                    break;
                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    message = "Unknown";
                    break;
            }
            statusLabel.setText(message);

            //배터리 잔량 표시
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percentage = level * 100 / scale;
            percentageLabel.setText(percentage + "%");
        }
    }
}