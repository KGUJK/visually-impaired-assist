package com.example.myapplication;
import android.os.AsyncTask;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
//날씨 파싱하는 코드
public class ReceiveWeatherTask extends AsyncTask<String, Void, JSONObject> {

    //마지막 출력을 위해
    public interface AsyncResponse {
        void processFinish(String output);
    }
    public AsyncResponse delegate = null;

    public ReceiveWeatherTask(AsyncResponse delegate){
        this.delegate = delegate;
    }

    //첫 실행될 경우 실행행
   @Override
    protected void onPreExecute(){
        super.onPreExecute();
    }

    //백그라운드에서 실행되는 코드
    @Override
    protected JSONObject doInBackground(String... data) {
        try{
            //인터넷 접속
            HttpURLConnection conn = (HttpURLConnection) new URL(data[0]).openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.connect();
            //실행된 경우 json을 한줄씩 읽음
            //이상하게 while문쓰면 에러나서 걍 한줄만 읽음(한줄에 필요한정보 다 있다)
            if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){
                InputStream is = conn.getInputStream();
                InputStreamReader reader = new InputStreamReader(is);
                BufferedReader in = new BufferedReader(reader);
                String read;
                read = in.readLine();
                JSONObject jObject = new JSONObject(read);
                return jObject;
                /*
                while ((read = in.readLine()) != null) {

                }
                */
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //읽어온 json을 정리
    @Override
    protected void onPostExecute(JSONObject result){
        //날씨 기온 습도만 뽑아쓰지만 필요하면 더 사용가능하고
        //날씨 이미지도 가져올 수 있음
        if(result != null){
            //String iconName = "";
            String nowTemp = "";
            String humidity = "";
            //String main = "";
            String description = "";
            try{
                //iconName = result.getJSONArray("weather").getJSONObject(0).getString("icon");
                nowTemp = result.getJSONObject("main").getString("temp");
                humidity = result.getJSONObject("main").getString("humidity");
                //main = result.getJSONArray("weather").getJSONObject(0).getString("main");
                description = result.getJSONArray("weather").getJSONObject(0).getString("description");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            description = transferWeather (description);
            final String msg = description + " ,습도" + humidity + "%, 현재 기온:" + nowTemp + "\u200E°C";
            //msg를 돌려보냄
            delegate.processFinish(msg);
        }
    }

    //날씨 영어로 준걸 한글로 변환하는 과정
    //아직 정리하지 않은 날씨도 있으니 시간남으면 정리해보기?
    private String transferWeather(String weather){
        weather = weather.toLowerCase();

        if(weather.equals("haze")){
            return "안개";
        }
        else if(weather.equals("fog")){
            return "안개";
        }
        else if(weather.equals("clouds")){
            return "구름";
        }
        else if(weather.equals("few clouds")){
            return "구름 조금";
        }
        else if(weather.equals("scattered clouds")){
            return "구름 낌";
        }
        else if(weather.equals("broken clouds")){
            return "구름 많음";
        }
        else if(weather.equals("overcast clouds")){
            return "구름 많음";
        }
        else if(weather.equals("clear sky")){
            return "맑음";
        }
        return "";
    }
}
