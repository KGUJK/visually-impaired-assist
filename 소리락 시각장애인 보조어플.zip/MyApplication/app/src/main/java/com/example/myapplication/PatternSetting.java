package com.example.myapplication;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Toast;

public class PatternSetting extends Activity {
    public String password="";
    private boolean startrecord = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_setting_pattern);

    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences sf = getSharedPreferences("pattern",0);
        SharedPreferences.Editor editor = sf.edit();
        String str =password.toString();
        editor.putString("password",str);
        editor.commit();
    }

    public boolean onTouchEvent(MotionEvent event) {
        // TODO Auto-generated method stub
        super.onTouchEvent(event);
        if(event.getAction() == MotionEvent.ACTION_DOWN ){
            if(!startrecord){
                password = "";
                startrecord = true;
            }
            Display display = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            float x = event.getX();
            float y = event.getY();
            float y_1 = size.y/4;
            float x_1 = size.x/2;
            int count_y = 0;
            int count_x = 0;
            if (y < y_1) {
                count_y = 1;
            }
            else if (y < (y_1*2)){
                count_y = 2;
            }
            else if (y < (y_1*3)){
                count_y = 3;
            }
            else {
                count_y = 4;
            }
            if (x < x_1) {
                count_x = 1;
            }
            else {
                count_x = 2;
            }
            password = password + count_x +""+ count_y;
            //Toast.makeText(PatternSetting. this, password, Toast.LENGTH_SHORT ).show();
            if(password.length()==8){
                onStop();
                finish();
                SharedPreferences sf = getSharedPreferences("pattern",0);
                sf.getString("password","");
                Toast.makeText(PatternSetting. this, "설정 완료" , Toast.LENGTH_SHORT ).show();
            }
            return true;

        }
        return false;
    }
}
