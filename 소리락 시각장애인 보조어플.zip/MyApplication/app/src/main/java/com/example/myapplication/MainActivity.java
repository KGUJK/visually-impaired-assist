package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.view.View;

//메인 화면 (여기에 설정 넣어주세요)
public class MainActivity extends AppCompatActivity {
    private Button onBtn, offBtn, pass_setting, setup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onBtn= (Button)findViewById(R.id.btn_lock1);
        offBtn= (Button)findViewById(R.id.btn_lock2);
        pass_setting = (Button)findViewById(R.id.pass_setting);
        setup = (Button)findViewById(R.id.setup);
        onBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LockScreenService.class);
                startService(intent);
            }

        });
        offBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LockScreenService.class);
                stopService(intent);
            }
        });
        setup.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO : click event
                Intent intent = new Intent(MainActivity.this, SettingFragment.class);

                startActivity(intent);
            }
        });
        pass_setting.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO : click event
                Intent intent = new Intent(MainActivity.this, PatternSetting.class);
                startActivity(intent);
            }
        });
    }

}
