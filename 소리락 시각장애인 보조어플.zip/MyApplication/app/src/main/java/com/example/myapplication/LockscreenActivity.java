package com.example.myapplication;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

//잠금 화면 처리 부분
public class LockscreenActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int MILLISINFUTURE = 11*300;
    private static int REQUEST_ACCESS_FINE_LOCATION = 1000;
    private static int REQUEST_ACCESS_COARSE_LOCATION = 1000;
    private int count = 3;
    private String recorddata="";
    private boolean startrecord = true;
    private static final int COUNT_DOWN_INTERVAL = 1000;
    private BatteryReceiver mBatteryReceiver = new BatteryReceiver();
    private IntentFilter mIntentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
    private Timer mTimer;
    private CountDownTimer countDownTimer;
    private TextToSpeech tts;
    private View 	decorView;
    private int	uiOption;
    private TextView timeTv, logView, percentLabel,weatherTv;
    private double lat,lng;

    //tts의 경우 text라는 변수명에 들어있는 값이 읽어짐
    //위치 tts
    private void Speech_loc() {
        String text = logView.getText().toString().trim();
        tts.setPitch((float) 1.0);
        tts.setSpeechRate((float) 1.0); // 재생속도
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    //배터리 tts
    private void Speech_ba() {
        String text = percentLabel.getText().toString().trim();
        tts.setPitch((float) 1.0);
        tts.setSpeechRate((float) 1.0); // 재생속도
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    //시간 tts
    private void Speech_time() {
        String text = timeTv.getText().toString().trim();
        tts.setPitch((float) 1.0);
        tts.setSpeechRate((float) 1.0); // 재생속도
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    //날씨 tts (에러 tts도 같이 사용)
    private void Speech_weather() {
        String text = weatherTv.getText().toString().trim();
        tts.setPitch((float) 1.0);
        tts.setSpeechRate((float) 1.0); // 재생속도
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }


    //날씨 가져오는 부분 (좌표값을 ReceieveWeatherTask로 넘겨줌
    private void getWeather(double lat, double lng) {
        //openweathermap API 사용
        String url = "http://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lng + "&units=metric&appid=ef2dc5c59bae55385cb04425687aa96f";
        //AsyncTask를 사용해서 백그라운드에서 작업
        ReceiveWeatherTask receiveUseTask = (ReceiveWeatherTask) new ReceiveWeatherTask(new ReceiveWeatherTask.AsyncResponse(){
            @Override
            public void processFinish(String output) {
                weatherTv.setText(output);
            }
        }).execute(url);
    }

    //좌표값을 위치 정보로 전환하는 함수 (Geocoder 사용)
    private void getLocation(double lat, double lng){
        String str = null;
        Geocoder geocoder = new Geocoder(this, Locale.KOREA);
        List<Address> address;
        try {
            if (geocoder != null) {
                address = geocoder.getFromLocation(lat, lng, 1);
                if (address != null && address.size() > 0) {
                    str = address.get(0).getAddressLine(0).toString();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //str에 위치 정보가 저장되어있음
        logView.setText(str);
    }

    @Override
    public void onInit(int status) {
        //tts 설정 부분
        if (status == TextToSpeech.SUCCESS) {
            // 작업 성공
            int language = tts.setLanguage(Locale.KOREAN);  // 언어 설정
            if (language == TextToSpeech.LANG_MISSING_DATA
                    || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                // 언어 데이터가 없거나, 지원하지 않는경우
                Toast.makeText(this, "지원하지 않는 언어입니다.", Toast.LENGTH_SHORT).show();
            } else {
                // 준비 완료
            }
        } else {
            // 작업 실패
            Toast.makeText(this, "TTS 작업에 실패하였습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    //ui 상단바, 하단바 지우는 코드
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        // TODO Auto-generated method stub
        // super.onWindowFocusChanged(hasFocus);
        if( hasFocus ) {
            decorView.setSystemUiVisibility( uiOption );
        }
    }

    //터치 이벤트 (잠금해제 및 tts 출력용)
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // TODO Auto-generated method stub
        super.onTouchEvent(event);
        if(event.getAction() == MotionEvent.ACTION_DOWN ){
            //터치할 경우 타이머를 종료시키고 3초로 다시 실행
            countDownTimer.cancel();
            count = 3;
            countDownTimer.start();
            if(!startrecord){
                //처음 터치인지 확인용
                recorddata = "";
                startrecord = true;
            }
            Display display = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            float x = event.getX();
            float y = event.getY();
            //화면의 크기를 따온 후 8등분 시키는 코드
            float y_1 = size.y/4;
            float x_1 = size.x/2;
            int count_y = 0;
            int count_x = 0;
            //터치한 곳이 8등분 된 영역중 어느 곳인지 알아내는 코드
            if (y < y_1) {
                count_y = 1;
            }
            else if (y < (y_1*2)){
                count_y = 2;
            }
            else if (y < (y_1*3)){
                count_y = 3;
            }
            else {
                count_y = 4;
            }
            if (x < x_1) {
                count_x = 1;
            }
            else {
                count_x = 2;
            }
            //recorddata에 터치한 영역이 계속 저장되며 이를 db와 대조하여 기능 수행
            recorddata = recorddata + count_x +""+ count_y;
            return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_screen);
        //잠금화면 설정 부분 (화면 끈 후 키면 나오도록)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        //ui 하단바 상단바 쪽 코드
        decorView = getWindow().getDecorView();
        uiOption = getWindow().getDecorView().getSystemUiVisibility();
        //타이머 설정 및 실행부분 (잠금해제용 타이머, 시간의 실시간 표시용 타이머)
        MainTimerTask timerTask = new MainTimerTask();
        mTimer = new Timer();
        mTimer.schedule(timerTask, 500, 1000);
        //textview 설정
        timeTv = (TextView) findViewById(R.id.time_tv);
        tts = new TextToSpeech(this, this);
        logView = (TextView) findViewById(R.id.logView);
        weatherTv = (TextView) findViewById(R.id.weather);
        percentLabel = (TextView) findViewById(R.id.percentageLabel);
        //잠금해제 타이머 실행
        countDownTimer();
        //안드로이드 버전마다 다른 상하단바 영역에 관한 코드
        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH )
            uiOption |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN )
            uiOption |= View.SYSTEM_UI_FLAG_FULLSCREEN;
        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT )
            uiOption |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        //위치 좌표를 알아내는 코드
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                //위치가 변경될 경우 변경된 위도,경도를 저장
                //해당 코드에 의해서 어플의 부하가 있으므로 나중에는 수동 갱신으로 변경하면 어떨까
                lat = location.getLatitude();
                lng = location.getLongitude();
            }
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }
            public void onProviderEnabled(String provider) {
            }
            public void onProviderDisabled(String provider) {
            }
        };
        //위치 권한 가져오는 코드 해당 코드를 앱 실행시 작동하도록 변경하면 어떨까
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
            if(permissionCheck == PackageManager.PERMISSION_DENIED){
                // 권한 없을 경우
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_ACCESS_FINE_LOCATION);
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                        REQUEST_ACCESS_COARSE_LOCATION);
            }
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        String locationProvider = LocationManager.GPS_PROVIDER;
        Location lastKnownLocation = locationManager.getLastKnownLocation(locationProvider);
        //마지막으로 가져온 위치가 있을 경우 그 위치 표시
        if (lastKnownLocation != null) {
            double lng = lastKnownLocation.getLatitude();
            double lat = lastKnownLocation.getLatitude();
        }
    }
    //앱이 종료될 경우 tts 기능의 종료
    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    //실시간 현재 시간 표시용 타이머
    private Handler mHandler = new Handler();
    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            Date rightNow = new Date();
            //여기를 수정하면 출력될 시간의 틀 변경가능
            SimpleDateFormat formatter = new SimpleDateFormat(
                    "MM월 dd일 E요일\nhh시 mm분",Locale.KOREAN);
            String dateString = formatter.format(rightNow);
            timeTv.setText(dateString);
        }
    };

    //잠금화면용 타이머
    public void countDownTimer(){
        //1초마다 체크되는 중
        countDownTimer = new CountDownTimer(MILLISINFUTURE, COUNT_DOWN_INTERVAL) {
            public void onTick(long millisUntilFinished) {
                //초마다 count를 하나씩 줄이고 0이 되면 종료
                //.equals안의 값을 db와 연동시키면 됩니다 부탁들려요
                SharedPreferences sf = getSharedPreferences("pattern",0);
                sf.getString("password","");
                count --;
                //입력 칸 (DB연동 필요)
                if(recorddata.equals(sf.getString("password",""))){
                    finish();
                    //잠금해제
                }
                else if (recorddata.equals("142424")){
                    countDownTimer.cancel();
                    recorddata="";
                    Speech_ba();
                    //배터리 잔량 TTS
                }
                else if (recorddata.equals("141424")){
                    countDownTimer.cancel();
                    recorddata="";
                    Speech_time();
                    //시간 TTS
                }
                //날씨의 경우 AsyncTask가 좀 느려서 tts를 2초 지난 후 출력(바로 출력하면 받아오는거보다 tts출력이 먼저 실행되서 안읽음)
                else if (recorddata.equals("21222122")){
                    countDownTimer.cancel();
                    recorddata="";
                    getWeather(lat,lng);
                    Handler mHandler = new Handler();
                    mHandler.postDelayed(new Runnable()  {
                        public void run() {
                            Speech_weather();
                        }
                    }, 2000);
                }
                else if (recorddata.equals("11121112")){
                    countDownTimer.cancel();
                    recorddata="";
                    getLocation(lat,lng);
                    Speech_loc();
                }
            }
            //타이머가 종료되ㅣㄹ 경우 날씨 출력에 쓰던 textview를 사용해 잘못된 비밀번호임을 출력하고
            //2초후에 텍스트를 지운다
            public void onFinish() {
                weatherTv.setText("잘못된 비밀번호입니다");
                startrecord = false;
                Speech_weather();
                Handler mHandler = new Handler();
                mHandler.postDelayed(new Runnable()  {
                    public void run() {
                        weatherTv.setText("");
                    }
                }, 2000);
            }
        };
    }

    class MainTimerTask extends TimerTask {
        public void run() {
            mHandler.post(mUpdateTimeTask);
        }
    }
}

